"""
URL configuration for chatwithme project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from talkapp.views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',signup,name='signup'),
    path('login/',login_view,name='login'),
    path('profile/',profile,name='profile'),
    path('logout/',log_outt,name='logout'),
    path('send_request/<int:user_id>/', send_request, name='send_request'),
    path('accept_request/<int:request_id>/',accept_request, name='accept_request'),
    path('decline_request/<int:request_id>/',decline_request, name='decline_request'),
    path('unfollow/<int:user_id>/', unfollow, name='unfollow'),
    path('user_profile/<int:user_id>/',user_profile, name='user_profile'),
    path('edit_profile/', edit_profile, name='edit_profile'),
]
