from django import forms
from .models import *

class Chat_Content_Forms(forms.ModelForm):
    class Meta:
        model=Chat
        fields='__all__'